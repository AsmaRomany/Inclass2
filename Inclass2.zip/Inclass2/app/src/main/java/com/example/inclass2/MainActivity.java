package com.example.inclass2;

import static com.example.inclass2.R.layout.activity_main;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    private Spinner spn ;
    private Button btn;
    private EditText edtName;
    private EditText edtSalary;
    private ListView List ;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(activity_main);
        spn =findViewById(R.id.spn1);
        btn = findViewById(R.id.btnAdd);
        edtName =findViewById(R.id.edtName);
        edtSalary = findViewById(R.id.edtSalary);
        List = findViewById(R.id.LV1);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddTolist();
            }
        });



    }
    public void AddTolist(){
        Emploay [] e = new Emploay[50];
        Emploay E;
        E = new Emploay(edtName.getText().toString(), edtSalary.getText());
        String time=  spn.getSelectedItem().toString();
        ArrayAdapter adapter = new ArrayAdapter(this, List,);

        List.setAdapter(adapter);


    }
}