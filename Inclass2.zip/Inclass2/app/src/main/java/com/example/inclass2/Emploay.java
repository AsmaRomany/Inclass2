package com.example.inclass2;

public class Emploay {
    private String Name ;
    private float salary ;
    public Emploay(){}
    public Emploay(String Name, float salary ){
        this.Name = Name;
        this.salary = salary;
    }

    public String getName() {
        return Name;
    }

    public void setName(String title) {
        this.Name = title;
    }

    public float getAuthor() {
        return salary;
    }

    public void setAuthor(float salary) {
        this.salary = salary;
    }
}
